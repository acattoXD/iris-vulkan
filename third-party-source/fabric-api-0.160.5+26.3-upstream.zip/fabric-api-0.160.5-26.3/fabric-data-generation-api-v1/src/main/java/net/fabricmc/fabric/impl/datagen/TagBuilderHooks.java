/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.datagen;

import java.util.List;

import net.minecraft.resources.Identifier;
import net.minecraft.tags.TagEntry;

public interface TagBuilderHooks {
	void fabric_setReplace(boolean replace);

	boolean fabric_isReplaced();

	void fabric_forceAddTag(Identifier tag);

	List<TagEntry> fabric_getRemove();

	void fabric_removeElement(Identifier id);

	void fabric_removeTag(Identifier tag);
}
