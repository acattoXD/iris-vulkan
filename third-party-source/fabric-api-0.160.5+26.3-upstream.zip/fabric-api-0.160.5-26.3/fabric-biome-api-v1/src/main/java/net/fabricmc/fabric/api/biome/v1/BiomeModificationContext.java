/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.biome.v1;

import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.function.BiPredicate;

import org.jetbrains.annotations.UnmodifiableView;

import net.minecraft.resources.ResourceKey;
import net.minecraft.util.random.Weighted;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributeMap;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.world.attribute.modifier.AttributeModifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeSpecialEffects;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.carver.WorldCarver;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

/**
 * Allows {@link Biome} properties to be modified.
 */
public interface BiomeModificationContext {
	/**
	 * Returns the modification context for the biomes weather properties.
	 */
	WeatherContext getWeather();

	/**
	 * Returns the modification context for the biomes environment attributes.
	 */
	AttributesContext getAttributes();

	/**
	 * Returns the modification context for the biomes effects.
	 */
	EffectsContext getEffects();

	/**
	 * Returns the modification context for the biomes generation settings.
	 */
	GenerationSettingsContext getGenerationSettings();

	/**
	 * Returns the modification context for the biomes mob spawn settings.
	 */
	MobSpawnSettingsContext getMobSpawnSettings();

	interface WeatherContext {
		/**
		 * @see Biome#hasPrecipitation()
		 * @see Biome.BiomeBuilder#hasPrecipitation(boolean)
		 */
		void setPrecipitation(boolean hasPrecipitation);

		/**
		 * @see Biome#getBaseTemperature()
		 * @see Biome.BiomeBuilder#temperature(float)
		 */
		void setTemperature(float temperature);

		/**
		 * @see Biome.BiomeBuilder#temperatureAdjustment(Biome.TemperatureModifier)
		 */
		void setTemperatureModifier(Biome.TemperatureModifier temperatureModifier);

		/**
		 * @see Biome.BiomeBuilder#downfall(float)
		 */
		void setDownfall(float downfall);
	}

	interface AttributesContext {
		/**
		 * @see Biome.BiomeBuilder#putAttributes(EnvironmentAttributeMap)
		 */
		void addAll(EnvironmentAttributeMap map);

		/**
		 * @see Biome.BiomeBuilder#putAttributes(EnvironmentAttributeMap.Builder)
		 */
		default void addAll(EnvironmentAttributeMap.Builder map) {
			this.addAll(map.build());
		}

		/**
		 * @see Biome.BiomeBuilder#setAttribute(EnvironmentAttribute, Object)
		 */
		<T> void set(EnvironmentAttribute<T> key, T value);

		/**
		 * @see Biome.BiomeBuilder#modifyAttribute(EnvironmentAttribute, AttributeModifier, Object)
		 */
		<T, M> void setModifier(EnvironmentAttribute<T> key, AttributeModifier<T, M> modifier, M value);
	}

	interface EffectsContext {
		/**
		 * @deprecated Set the fog color using environment attributes instead
		 * @see BiomeModificationContext#getAttributes()
		 * @see EnvironmentAttributes#FOG_COLOR
		 */
		@Deprecated
		void setFogColor(int color);

		/**
		 * @see BiomeSpecialEffects#waterColor()
		 * @see BiomeSpecialEffects.Builder#waterColor(int)
		 */
		void setWaterColor(int color);

		/**
		 * @deprecated Set the water fog color using environment attributes instead
		 * @see BiomeModificationContext#getAttributes()
		 * @see EnvironmentAttributes#WATER_FOG_COLOR
		 */
		@Deprecated
		void setWaterFogColor(int color);

		/**
		 * @deprecated Set the sky color using environment attributes instead
		 * @see BiomeModificationContext#getAttributes()
		 * @see EnvironmentAttributes#SKY_COLOR
		 */
		@Deprecated
		void setSkyColor(int color);

		/**
		 * @see BiomeSpecialEffects#foliageColorOverride()
		 * @see BiomeSpecialEffects.Builder#foliageColorOverride(int)
		 */
		void setFoliageColorOverride(Optional<Integer> color);

		/**
		 * @see BiomeSpecialEffects#foliageColorOverride()
		 * @see BiomeSpecialEffects.Builder#foliageColorOverride(int)
		 */
		default void setFoliageColorOverride(int color) {
			setFoliageColorOverride(Optional.of(color));
		}

		/**
		 * @see BiomeSpecialEffects#foliageColorOverride()
		 * @see BiomeSpecialEffects.Builder#foliageColorOverride(int)
		 */
		default void setFoliageColorOverride(OptionalInt color) {
			color.ifPresentOrElse(this::setFoliageColorOverride, this::clearFoliageColorOverride);
		}

		/**
		 * @see BiomeSpecialEffects#foliageColorOverride()
		 * @see BiomeSpecialEffects.Builder#foliageColorOverride(int)
		 */
		default void clearFoliageColorOverride() {
			setFoliageColorOverride(Optional.empty());
		}

		/**
		 * @see BiomeSpecialEffects#dryFoliageColorOverride()
		 * @see BiomeSpecialEffects.Builder#dryFoliageColorOverride(int)
		 */
		void setDryFoliageColorOverride(Optional<Integer> color);

		/**
		 * @see BiomeSpecialEffects#dryFoliageColorOverride()
		 * @see BiomeSpecialEffects.Builder#dryFoliageColorOverride(int)
		 */
		default void setDryFoliageColorOverride(int color) {
			setDryFoliageColorOverride(Optional.of(color));
		}

		/**
		 * @see BiomeSpecialEffects#dryFoliageColorOverride()
		 * @see BiomeSpecialEffects.Builder#dryFoliageColorOverride(int)
		 */
		default void setDryFoliageColorOverride(OptionalInt color) {
			color.ifPresentOrElse(this::setDryFoliageColorOverride, this::clearDryFoliageColorOverride);
		}

		/**
		 * @see BiomeSpecialEffects#dryFoliageColorOverride()
		 * @see BiomeSpecialEffects.Builder#dryFoliageColorOverride(int)
		 */
		default void clearDryFoliageColorOverride() {
			setDryFoliageColorOverride(Optional.empty());
		}

		/**
		 * @see BiomeSpecialEffects#grassColorOverride()
		 * @see BiomeSpecialEffects.Builder#grassColorOverride(int)
		 */
		void setGrassColorOverride(Optional<Integer> color);

		/**
		 * @see BiomeSpecialEffects#grassColorOverride()
		 * @see BiomeSpecialEffects.Builder#grassColorOverride(int)
		 */
		default void setGrassColorOverride(int color) {
			setGrassColorOverride(Optional.of(color));
		}

		/**
		 * @see BiomeSpecialEffects#grassColorOverride()
		 * @see BiomeSpecialEffects.Builder#grassColorOverride(int)
		 */
		default void setGrassColorOverride(OptionalInt color) {
			color.ifPresentOrElse(this::setGrassColorOverride, this::clearGrassColorOverride);
		}

		/**
		 * @see BiomeSpecialEffects#grassColorOverride()
		 * @see BiomeSpecialEffects.Builder#grassColorOverride(int)
		 */
		default void clearGrassColorOverride() {
			setGrassColorOverride(Optional.empty());
		}

		/**
		 * @see BiomeSpecialEffects#grassColorOverride()
		 * @see BiomeSpecialEffects.Builder#grassColorModifier(BiomeSpecialEffects.GrassColorModifier)
		 */
		void setGrassColorModifier(BiomeSpecialEffects.GrassColorModifier colorModifier);

		/**
		 * @deprecated Set the music volume using environment attributes instead
		 * @see BiomeModificationContext#getAttributes()
		 * @see EnvironmentAttributes#MUSIC_VOLUME
		 */
		@Deprecated
		void setMusicVolume(float volume);
	}

	interface GenerationSettingsContext {
		/**
		 * Removes a feature from one of this biomes generation steps, and returns if any features were removed.
		 */
		boolean removeFeature(GenerationStep.Decoration step, ResourceKey<PlacedFeature> placedFeatureKey);

		/**
		 * Removes a feature from all of this biomes generation steps, and returns if any features were removed.
		 */
		default boolean removeFeature(ResourceKey<PlacedFeature> placedFeatureKey) {
			boolean anyFound = false;

			for (GenerationStep.Decoration step : GenerationStep.Decoration.values()) {
				if (removeFeature(step, placedFeatureKey)) {
					anyFound = true;
				}
			}

			return anyFound;
		}

		/**
		 * Adds a feature to one of this biomes generation steps, identified by the placed feature's resource key.
		 */
		void addFeature(GenerationStep.Decoration step, ResourceKey<PlacedFeature> placedFeatureKey);

		/**
		 * Adds a world carver to this biome.
		 */
		void addCarver(ResourceKey<WorldCarver> carverKey);

		/**
		 * Removes all carvers with the given key from this biome.
		 *
		 * @return True if any carvers were removed.
		 */
		boolean removeCarver(ResourceKey<WorldCarver> carverKey);
	}

	interface MobSpawnSettingsContext {
		/**
		 * Associated environment attribute: {@link EnvironmentAttributes#CREATURE_WORLD_GEN_SPAWN_PROBABILITY}.
		 */
		void setCreatureGenerationProbability(float probability);

		/**
		 * Provides a view of all spawns of the given category.
		 *
		 * <p>Associated environment attribute: {@link EnvironmentAttributes#NATURAL_MOB_SPAWNS}.
		 *
		 * @see MobSpawnSettings#getMobsToSpawn(MobCategory)
		 */
		@UnmodifiableView List<Weighted<MobSpawnSettings.SpawnerData>> getMobs(MobCategory category);

		/**
		 * Associated environment attribute: {@link EnvironmentAttributes#NATURAL_MOB_SPAWNS}.
		 *
		 * @see MobSpawnSettings#getMobsToSpawn(MobCategory)
		 * @see MobSpawnSettings.Builder
		 */
		void addSpawn(MobCategory category, MobSpawnSettings.SpawnerData data, int weight);

		/**
		 * Removes any spawns matching the given predicate from this biome, and returns true if any matched.
		 *
		 * <p>Associated environment attribute: {@link EnvironmentAttributes#NATURAL_MOB_SPAWNS}.
		 */
		boolean removeSpawns(BiPredicate<MobCategory, MobSpawnSettings.SpawnerData> predicate);

		/**
		 * Removes all spawns of the given entity type.
		 *
		 * <p>Associated environment attribute: {@link EnvironmentAttributes#NATURAL_MOB_SPAWNS}.
		 *
		 * @return True if any spawns were removed.
		 */
		default boolean removeSpawnsOfEntityType(EntityType<?> entityType) {
			return removeSpawns((category, spawnEntry) -> spawnEntry.type() == entityType);
		}

		/**
		 * Removes all spawns of the given category.
		 *
		 * <p>Associated environment attribute: {@link EnvironmentAttributes#NATURAL_MOB_SPAWNS}.
		 */
		default void clearSpawns(MobCategory category) {
			removeSpawns((mobCategory, spawnEntry) -> mobCategory == category);
		}

		/**
		 * Removes all spawns.
		 *
		 * <p>Associated environment attribute: {@link EnvironmentAttributes#NATURAL_MOB_SPAWNS}.
		 */
		default void clearSpawns() {
			removeSpawns((mobCategory, spawnEntry) -> true);
		}

		/**
		 * Associated environment attribute: {@link EnvironmentAttributes#NATURAL_MOB_SPAWNS}.
		 *
		 * @see MobSpawnSettings#getMobSpawnCost(EntityType)
		 * @see MobSpawnSettings.Builder#addMobSpawnCost(EntityType, double, double)
		 */
		void addMobCharge(EntityType<?> entityType, double charge, double energyBudget);

		/**
		 * Removes a spawn cost entry for a given entity type.
		 *
		 * <p>Associated environment attribute: {@link EnvironmentAttributes#NATURAL_MOB_SPAWNS}.
		 */
		void clearMobCharge(EntityType<?> entityType);
	}
}
