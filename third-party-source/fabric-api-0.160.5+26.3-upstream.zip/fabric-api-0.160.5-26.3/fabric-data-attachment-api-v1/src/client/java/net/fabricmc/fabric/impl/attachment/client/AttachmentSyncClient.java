/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.attachment.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.impl.attachment.AttachmentEntrypoint;
import net.fabricmc.fabric.impl.attachment.sync.AttachmentSync;
import net.fabricmc.fabric.impl.attachment.sync.AttachmentSyncException;
import net.fabricmc.fabric.impl.attachment.sync.clientbound.ClientboundAttachmentSyncPayload;
import net.fabricmc.fabric.impl.attachment.sync.clientbound.ClientboundRequestAcceptedAttachmentsPayload;

public class AttachmentSyncClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// config
		ClientConfigurationNetworking.registerGlobalReceiver(
				ClientboundRequestAcceptedAttachmentsPayload.ID,
				(payload, context) -> context.responseSender().sendPacket(AttachmentSync.createResponsePayload())
		);

		// play
		ClientPlayNetworking.registerGlobalReceiver(
				ClientboundAttachmentSyncPayload.TYPE,
				(payload, context) -> {
					try {
						payload.attachment().tryApply(context.client().level);
					} catch (AttachmentSyncException e) {
						AttachmentEntrypoint.LOGGER.error("Error accepting attachment changes", e);
						context.responseSender().disconnect(e.getComponent());
					}
				}
		);
	}
}
